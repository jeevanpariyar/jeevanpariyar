<?php 

$arr = explode("@", "amit@gmail.com", 2); 
echo $arr[0];

?>