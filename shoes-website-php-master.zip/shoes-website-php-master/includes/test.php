<?php 

include_once('../test1.php');
?>